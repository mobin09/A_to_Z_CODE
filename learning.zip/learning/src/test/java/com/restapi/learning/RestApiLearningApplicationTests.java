package com.restapi.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
